# SimpleTrader
A full stack WPF MVVM trading application.

Follow along at https://www.youtube.com/playlist?list=PLA8ZIAm2I03jSfo18F7Y65XusYzDusYu5
