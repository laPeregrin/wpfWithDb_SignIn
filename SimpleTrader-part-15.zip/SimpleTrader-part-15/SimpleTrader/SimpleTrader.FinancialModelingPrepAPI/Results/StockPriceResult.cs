﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleTrader.FinancialModelingPrepAPI.Results
{
    public class StockPriceResult
    {
        public double Price { get; set; }
    }
}
