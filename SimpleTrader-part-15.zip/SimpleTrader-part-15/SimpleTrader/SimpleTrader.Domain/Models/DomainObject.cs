﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleTrader.Domain.Models
{
    public class DomainObject
    {
        public int Id { get; set; }
    }
}
